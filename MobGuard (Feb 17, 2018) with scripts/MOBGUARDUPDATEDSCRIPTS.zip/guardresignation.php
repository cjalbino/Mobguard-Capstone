 <?php
    require "conn.php";

    $reason = $_POST["reason"];
    $mysql_qry = "insert into resignation (secu_id, reason, date, status) values ('SECU0','$reason',sysdate(),'waiting');";
  
    
    if(mysqli_query($conn,$mysql_qry))  
    {

    echo "resignation request sent!";
    }
    else
    {
        
    echo $mysql_qry;
    }


   
?>