package com.example.chrisjerico.jubecermobileapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by ChrisJerico on 3/11/2017.
 */
public class Login extends AppCompatActivity {
    Button login;
    EditText username,password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        login = (Button)findViewById(R.id.btnlogin);
        username = (EditText)findViewById(R.id.userid);
        password = (EditText)findViewById(R.id.userpass);
    }
    public void onClicked(View view){

        String usernamesg = username.getText().toString();
        String passwordsg = password.getText().toString();
        String type = "login1";
        LoginClientBackgroundWorker loginclientbackgroundworker = new LoginClientBackgroundWorker(this);
        loginclientbackgroundworker.execute(type, usernamesg, passwordsg);

    }

}
