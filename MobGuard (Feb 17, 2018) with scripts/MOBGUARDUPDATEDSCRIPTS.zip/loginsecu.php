<?php
require "conn.php";
$user_email = $_POST["emailsecu"];
//$user_pass = $_POST["passwordsecu"];
$mysql_qry = "select * from employees where email like '$user_email'";
//and password like '$user_pass';" 
$result = mysqli_query($conn, $mysql_qry) or die (mysqli_error($conn));
if (mysqli_num_rows($result)>0){
	$row = mysqli_fetch_assoc($result);		
	$first_name = $row["first_name"];
	echo "login success , welcome ".$first_name;
}
else{
	echo "invalid credentials";
}
 
?>


