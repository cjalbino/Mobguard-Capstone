<?php
// Check connection
include "servicereqctr.php";
$host='127.0.0.1:3306';
$username='root';
$pwd='admin123';
$db='csig';

$con=mysqli_connect($host,$username,$pwd,$db) or die('Unable to connect');

    $client_id = "CLIENTz1";
    $services_id = 4;
 //   $service_desc =$_POST["desc"];
 //   $meeting_place =$_POST["place"]; 
 //   $meeting_date = $_POST["date"];
    $status = "active";
    $read = 0;

echo ($service_req_id);
     $mysql_qry = "insert into service_requests (id, client_id, services_id, desc_of_service, date_start, meetingPlace, meetingSchedule, status, isRead, created_at, updated_at) values ('$service_req_id','$client_id','$services_id','PersonalSecurity',sysdate(),'McDonalds', sysdate(),'active',0,sysdate(),sysdate());";
     
    if(mysqli_query($con,$mysql_qry))  
    {
    echo "request sent!";
    }
    else
    {
        
    echo $mysql_qry;
    }
/*
   $client_id = "CLIENTz1";
    $services_id = 4;
    $service_desc =$_POST["desc"];
    $meeting_place =$_POST["place"]; 
    $meeting_date = $_POST["date"];
    $status = "active";
    $read = 0;

    $service_req_id = "SERVREQ-";
    $mysql_qry = "insert into service_requests (id, client_id, services_id, desc_of_service, date_start, meetingPlace, meetingSchedule, status, isRead, created_at, updated_at) values ('SERVREQ-19','$client_id','$services_id','$service_desc',sysdate(),'$meeting_place', '$meeting_date','active',0,sysdate(),sysdate());";
    
    
    if(mysqli_query($con,$mysql_qry))  
    {
    echo "request sent!";
    }
    else
    {
        
    echo $mysql_qry;
    }


/*

    $result = mysqli_query($con, "SELECT * FROM service_requests");
    $numrows = mysqli_num_rows($result);
    $numrows++;
//    $final = mysqli_query($con, )
    print "There are $numrows service_requests\n";

 /*   if ($result=mysqli_query($con,$sql))
  {
    do 
    {

    }
  }

/*
$sql="Select id from service_requests";


if ($result=mysqli_query($con,$sql))
  {
  // Return the number of rows in result set
  $rowcount=mysqli_num_rows($result);
  $rowcount++;
  $service_req_id = "SERVREQ-".$rowcount;
  echo($service_req_id);
  do
  {
    $result1= mysqli
  }
 // $mysql_qry = "Insert into service_requests (id, client_id, services_id, desc_of_service, date_start, meetingPlace, meetingSchedule, status, isRead, created_at, updated_at) values ('$service_req_id','CLIENTz1',4,'Tayuman',sysdate(),'McDonalds', 'tomorrow','active',0,sysdate(),sysdate());";
  }

//else if (mysqli_query($con,$mysql_qry))
  //  {
   //     echo "sent!";
   // }


//  |   | CLIENTz4  |           5 | bjlnkjvgjh            | NULL                       | Anywhere        | 2017-01-12 00:00:00.000000 | active   |      1 | 2018-01-12 20:42:50 | 2018-01-12 20:42:50
mysqli_close($con);
*/
?>