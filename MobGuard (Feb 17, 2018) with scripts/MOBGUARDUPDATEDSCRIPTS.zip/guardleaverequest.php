 <?php
    require "conn.php";
  
    $employees_id = "secu0";
    $leaves_id = 1;
    $startdate =$_POST["startdate"];
    $enddate =$_POST["enddate"];
    $reason =$_POST["reason"]; 
    
    $status = "active";
    $deployed = "deployed";

    $mysql_qry = "insert into leave_request (employees_id,leaves_id,reason,status,deployed,created_at,updated_at,notif_date,start_date,end_date) values ('SECU0',5, '$reason','$status','$deployed',sysdate(),sysdate(),sysdate(),'$startdate','$enddate');";

    if(mysqli_query($conn,$mysql_qry))
    {
    echo "leave request sent!";
    }
    else
    {
    echo $mysql_qry;
    }


   
?>