<?php
$db_name="csig";
$mysql_username="root";
$mysql_password="admin123";
$server_name="127.0.0.2:3306";
$conn=mysqli_connect($server_name, $mysql_username, $mysql_password, $db_name);
?>