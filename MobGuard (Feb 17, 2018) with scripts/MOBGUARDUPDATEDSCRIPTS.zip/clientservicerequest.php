 <?php
    require "conn.php";
    include "servicereqctr.php";
    $client_id = "CLIENTz1";
    $services_id = 4;
    $service_desc =$_POST["desc"];
    $meeting_place =$_POST["place"]; 
    $meeting_date = $_POST["date"];
    $status = "active";
    $read = 0;

    $mysql_qry = "insert into service_requests (id, client_id, services_id, desc_of_service, date_start, meetingPlace, meetingSchedule, status, isRead, created_at, updated_at) values ('$service_req_id','$client_id','$services_id','$service_desc',sysdate(),'$meeting_place', '$meeting_date','active',0,sysdate(),sysdate());";
    

    
    if(mysqli_query($conn,$mysql_qry))  
    {
    echo "service request sent!";
    }
    else
    {
        
    echo $mysql_qry;
    }


   
?>