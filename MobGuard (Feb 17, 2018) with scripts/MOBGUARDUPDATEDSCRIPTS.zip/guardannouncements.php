<?php
$host='127.0.0.1:3306';
$username='root';
$pwd='admin123';
$db='csig';

$con=mysqli_connect($host,$username,$pwd,$db) or die('Unable to connect');
if(mysqli_connect_error($con))
{
	echo "Failed to Connect to Database".mysqli_connect_error();
}

$mysql_qry="SELECT * FROM announcement"; 
$result= mysqli_query($con,$mysql_qry);

if($result)
{
	while($row=mysqli_fetch_array($result))
	{
		$data[] =$row;
	}
	print(json_encode($data));
}
mysqli_close($con)
?>






