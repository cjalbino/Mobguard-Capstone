 <?php
    require "conn.php";
    include "addguardctr.php";
  
    $no_guards = $_POST["no_guards"];
    $converted_no = (int)$no_guards;
    $shift_start = $_POST["shift_start"];
    $shift_end =$_POST["shift_end"];
    $date_needed =$_POST["date_needed"]; 
    $status = "active";
    $mysql_qry = "insert into add_guard_requests (id, admin, client_id, establishments_id, no_guards, contract, shift_start, shift_end, date_needed, guardDeployed, status, created_at, updated_at) values ('$addguardctr','ADMIN1','CLIENTz0','ESTAB-CLIENTz0',$converted_no,'CONTRACT0', '$shift_start','$shift_end','$date_needed',11,'active',sysdate(),sysdate());";


    
    if(mysqli_query($conn,$mysql_qry))  
    {

    echo "additional guard request sent!";
    }
    else
    {
        
    echo $mysql_qry;
    }


   
?>