<?php
// Check connection
$host='127.0.0.1:3306';
$username='root';
$pwd='admin123';
$db='csig';

$con=mysqli_connect($host,$username,$pwd,$db) or die('Unable to connect');

  
 
    
$sql="Select id from service_requests";
//$sql = "insert into service_requests (id, client_id, services_id, desc_of_service, date_start, meetingPlace, meetingSchedule, status, isRead, created_at, updated_at) values ('SERVREQ-19','$client_id','$services_id','$service_desc',sysdate(),'$meeting_place', '$meeting_date','active',0,sysdate(),sysdate());";

if ($result=mysqli_query($con,$sql))
  {
  // Return the number of rows in result set
  $rowcount=mysqli_num_rows($result);
  $rowcount++;
  $service_req_id = "SERVREQ-".$rowcount;


  }

//else if (mysqli_query($con,$mysql_qry))
  //  {
   //     echo "sent!";
   // }


//  |   | CLIENTz4  |           5 | bjlnkjvgjh            | NULL                       | Anywhere        | 2017-01-12 00:00:00.000000 | active   |      1 | 2018-01-12 20:42:50 | 2018-01-12 20:42:50
mysqli_close($con);
?>